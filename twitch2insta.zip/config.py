# Fill these in with your credentials
TWITCH_CHANNEL = "yourchannelname"
INSTAGRAM_USERNAME = "yourusername"
INSTAGRAM_PASSWORD = "yourpassword"
